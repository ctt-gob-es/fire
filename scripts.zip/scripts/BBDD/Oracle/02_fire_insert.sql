-- ********************************************************
-- **************** Insercion datos ********************
-- ********************************************************

INSERT INTO TB_USUARIOS (nombre_usuario,clave,nombre,apellidos,usu_defecto) 
VALUES('admin','D/4avRoIIVNTwjPW4AlhPpXuxCU4Mqdhryj/N6xaFQw=','default name','default surnames',1);

COMMIT;
